//My first program

// deploying a class main
class Main {
  // main method of deploying strings in java
  public static void main(String[] args) {
    // printing out the statement Hello World
    System.out.println("Hello World!");
  }
}